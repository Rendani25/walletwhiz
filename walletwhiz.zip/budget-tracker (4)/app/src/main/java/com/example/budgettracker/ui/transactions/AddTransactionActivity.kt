package com.walletwiz.ui.transactions

import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.FileProvider
import androidx.lifecycle.ViewModelProvider
import com.walletwiz.R
import com.walletwiz.databinding.ActivityAddTransactionBinding
import com.example.budgettracker.model.Category
import com.example.budgettracker.model.Expense
import com.example.budgettracker.viewmodel.CategoryViewModel
import com.example.budgettracker.viewmodel.ExpenseViewModel
import java.io.File
import java.text.SimpleDateFormat
import java.util.*

class AddTransactionActivity : AppCompatActivity() {
    private lateinit var binding: ActivityAddTransactionBinding
    private lateinit var expenseViewModel: ExpenseViewModel
    private lateinit var categoryViewModel: CategoryViewModel

    private val dateFormat = SimpleDateFormat("MMM dd, yyyy", Locale.getDefault())
    private val timeFormat = SimpleDateFormat("HH:mm", Locale.getDefault())
    
    private var selectedDate = Calendar.getInstance()
    private var startTime = Calendar.getInstance()
    private var endTime = Calendar.getInstance().apply { add(Calendar.HOUR_OF_DAY, 1) }
    
    private var selectedCategoryId: Long = -1
    private var currentPhotoUri: Uri? = null
    private var isIncome = false
    
    private val categories = mutableListOf<Category>()

    // Camera result launcher
    private val takePictureLauncher = registerForActivityResult(
        ActivityResultContracts.TakePicture()
    ) { success ->
        if (success && currentPhotoUri != null) {
            binding.photoPreview.setImageURI(currentPhotoUri)
            binding.photoPreview.visibility = View.VISIBLE
            binding.removePhotoButton.visibility = View.VISIBLE
        }
    }

    // Gallery result launcher
    private val pickImageLauncher = registerForActivityResult(
        ActivityResultContracts.GetContent()
    ) { uri ->
        if (uri != null) {
            currentPhotoUri = uri
            binding.photoPreview.setImageURI(uri)
            binding.photoPreview.visibility = View.VISIBLE
            binding.removePhotoButton.visibility = View.VISIBLE
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityAddTransactionBinding.inflate(layoutInflater)
        setContentView(binding.root)

        expenseViewModel = ViewModelProvider(this)[ExpenseViewModel::class.java]
        categoryViewModel = ViewModelProvider(this)[CategoryViewModel::class.java]

        // Setup date and time pickers
        updateDateText()
        updateTimeTexts()
        
        binding.datePickerButton.setOnClickListener {
            showDatePicker()
        }
        
        binding.startTimePickerButton.setOnClickListener {
            showTimePicker(true)
        }
        
        binding.endTimePickerButton.setOnClickListener {
            showTimePicker(false)
        }

        // Setup transaction type toggle
        binding.expenseButton.setOnClickListener {
            isIncome = false
            updateTransactionTypeUI()
        }
        
        binding.incomeButton.setOnClickListener {
            isIncome = true
            updateTransactionTypeUI()
        }
        
        // Default to expense
        updateTransactionTypeUI()

        // Setup category spinner
        setupCategorySpinner()

        // Setup photo buttons
        binding.takePictureButton.setOnClickListener {
            takePhoto()
        }
        
        binding.chooseFromGalleryButton.setOnClickListener {
            chooseFromGallery()
        }
        
        binding.removePhotoButton.setOnClickListener {
            removePhoto()
        }

        // Save button
        binding.saveButton.setOnClickListener {
            saveTransaction()
        }

        // Cancel button
        binding.cancelButton.setOnClickListener {
            finish()
        }
    }

    private fun updateDateText() {
        binding.dateText.text = dateFormat.format(selectedDate.time)
    }

    private fun updateTimeTexts() {
        binding.startTimeText.text = timeFormat.format(startTime.time)
        binding.endTimeText.text = timeFormat.format(endTime.time)
    }

    private fun showDatePicker() {
        DatePickerDialog(
            this,
            { _, year, month, dayOfMonth ->
                selectedDate.set(year, month, dayOfMonth)
                updateDateText()
            },
            selectedDate.get(Calendar.YEAR),
            selectedDate.get(Calendar.MONTH),
            selectedDate.get(Calendar.DAY_OF_MONTH)
        ).show()
    }

    private fun showTimePicker(isStartTime: Boolean) {
        val calendar = if (isStartTime) startTime else endTime
        
        TimePickerDialog(
            this,
            { _, hourOfDay, minute ->
                calendar.set(Calendar.HOUR_OF_DAY, hourOfDay)
                calendar.set(Calendar.MINUTE, minute)
                
                // Ensure end time is after start time
                if (!isStartTime && calendar.before(startTime)) {
                    Toast.makeText(this, "End time must be after start time", Toast.LENGTH_SHORT).show()
                    calendar.time = startTime.time
                    calendar.add(Calendar.HOUR_OF_DAY, 1)
                }
                
                updateTimeTexts()
            },
            calendar.get(Calendar.HOUR_OF_DAY),
            calendar.get(Calendar.MINUTE),
            true
        ).show()
    }

    private fun updateTransactionTypeUI() {
        if (isIncome) {
            binding.expenseButton.setBackgroundResource(R.drawable.bg_button_unselected)
            binding.incomeButton.setBackgroundResource(R.drawable.bg_button_selector)
            binding.amountInputLayout.setHint("Income Amount")
        } else {
            binding.expenseButton.setBackgroundResource(R.drawable.bg_button_selector)
            binding.incomeButton.setBackgroundResource(R.drawable.bg_button_unselected)
            binding.amountInputLayout.setHint("Expense Amount")
        }
    }

    private fun setupCategorySpinner() {
        categoryViewModel.getAllCategories().observe(this) { categoryList ->
            categories.clear()
            categories.addAll(categoryList)
            
            val adapter = ArrayAdapter(
                this,
                android.R.layout.simple_spinner_item,
                categories.map { it.name }
            )
            adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
            binding.categorySpinner.adapter = adapter
            
            binding.categorySpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                    selectedCategoryId = categories[position].id
                }

                override fun onNothingSelected(parent: AdapterView<*>?) {
                    selectedCategoryId = -1
                }
            }
        }
    }

    private fun takePhoto() {
        val photoFile = createImageFile()
        currentPhotoUri = FileProvider.getUriForFile(
            this,
            "com.example.budgettracker.fileprovider",
            photoFile
        )
        takePictureLauncher.launch(currentPhotoUri)
    }

    private fun chooseFromGallery() {
        pickImageLauncher.launch("image/*")
    }

    private fun removePhoto() {
        currentPhotoUri = null
        binding.photoPreview.setImageURI(null)
        binding.photoPreview.visibility = View.GONE
        binding.removePhotoButton.visibility = View.GONE
    }

    private fun createImageFile(): File {
        val timeStamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(Date())
        val storageDir = getExternalFilesDir(null)
        return File.createTempFile(
            "JPEG_${timeStamp}_",
            ".jpg",
            storageDir
        )
    }

    private fun saveTransaction() {
        val amountStr = binding.amountEditText.text.toString()
        val description = binding.descriptionEditText.text.toString()

        if (amountStr.isEmpty()) {
            Toast.makeText(this, "Please enter an amount", Toast.LENGTH_SHORT).show()
            return
        }

        if (description.isEmpty()) {
            Toast.makeText(this, "Please enter a description", Toast.LENGTH_SHORT).show()
            return
        }

        if (selectedCategoryId == -1L) {
            Toast.makeText(this, "Please select a category", Toast.LENGTH_SHORT).show()
            return
        }

        try {
            val amount = amountStr.toDouble()
            
            // Combine date and time
            val date = Calendar.getInstance()
            date.set(
                selectedDate.get(Calendar.YEAR),
                selectedDate.get(Calendar.MONTH),
                selectedDate.get(Calendar.DAY_OF_MONTH),
                startTime.get(Calendar.HOUR_OF_DAY),
                startTime.get(Calendar.MINUTE)
            )
            
            val endDateTime = Calendar.getInstance()
            endDateTime.set(
                selectedDate.get(Calendar.YEAR),
                selectedDate.get(Calendar.MONTH),
                selectedDate.get(Calendar.DAY_OF_MONTH),
                endTime.get(Calendar.HOUR_OF_DAY),
                endTime.get(Calendar.MINUTE)
            )
            
            val expense = Expense(
                id = 0,
                amount = amount,
                description = description,
                date = date.timeInMillis,
                startTime = startTime.timeInMillis,
                endTime = endTime.timeInMillis,
                categoryId = selectedCategoryId,
                photoUri = currentPhotoUri?.toString() ?: "",
                isIncome = isIncome
            )
            
            expenseViewModel.insertExpense(expense)
            
            Toast.makeText(
                this,
                if (isIncome) "Income added successfully" else "Expense added successfully",
                Toast.LENGTH_SHORT
            ).show()
            
            finish()
        } catch (e: NumberFormatException) {
            Toast.makeText(this, "Please enter a valid amount", Toast.LENGTH_SHORT).show()
        }
    }
}
