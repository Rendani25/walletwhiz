package com.example.budgettracker.ui.categories

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.ViewGroup.LayoutParams
import android.widget.Toast
import androidx.fragment.app.DialogFragment
import androidx.lifecycle.ViewModelProvider
import com.walletwiz.R
import com.walletwiz.databinding.DialogAddCategoryBinding
import com.example.budgettracker.model.Category
import com.example.budgettracker.viewmodel.CategoryViewModel

class AddCategoryDialogFragment : DialogFragment() {

    private var _binding: DialogAddCategoryBinding? = null
    private val binding get() = _binding!!

    private lateinit var categoryViewModel: CategoryViewModel
    private var category: Category? = null

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = DialogAddCategoryBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        categoryViewModel = ViewModelProvider(requireActivity())[CategoryViewModel::class.java]

        // Check if we're editing an existing category
        arguments?.let {
            category = it.getParcelable(ARG_CATEGORY)
            category?.let { cat ->
                binding.categoryNameEditText.setText(cat.name)
                binding.categoryDescriptionEditText.setText(cat.description)
                binding.dialogTitle.text = "Edit Category"
                binding.saveButton.text = "Update"

                selectIconInUI(cat.iconResId)
            }
        }

        setupIconSelection()

        binding.saveButton.setOnClickListener {
            val name = binding.categoryNameEditText.text.toString().trim()
            val description = binding.categoryDescriptionEditText.text.toString().trim()
            val iconResId = getSelectedIconResId()

            if (name.isEmpty()) {
                Toast.makeText(requireContext(), "Please enter a category name", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            if (category == null) {
                val newCategory = Category(0, name, description, iconResId)
                categoryViewModel.insertCategory(newCategory)
            } else {
                val updatedCategory = category!!.copy(
                    name = name,
                    description = description,
                    iconResId = iconResId
                )
                categoryViewModel.updateCategory(updatedCategory)
            }

            dismiss()
        }

        binding.cancelButton.setOnClickListener {
            dismiss()
        }
    }

    override fun onStart() {
        super.onStart()
        dialog?.window?.setLayout(
            (resources.displayMetrics.widthPixels * 0.9).toInt(),  // Set dialog to 90% of screen width
            LayoutParams.WRAP_CONTENT
        )
    }

    private fun setupIconSelection() {
        val iconViews = listOf(
            binding.iconFood,
            binding.iconShopping,
            binding.iconTransport,
            binding.iconEntertainment,
            binding.iconHealth,
            binding.iconEducation,
            binding.iconBills,
            binding.iconOther
        )

        iconViews.forEach { iconView ->
            iconView.setOnClickListener {
                iconViews.forEach { it.setBackgroundResource(R.drawable.bg_icon_unselected) }
                iconView.setBackgroundResource(R.drawable.bg_icon_selected)
            }
        }

        binding.iconFood.setBackgroundResource(R.drawable.bg_icon_selected) // default selection
    }

    private fun selectIconInUI(iconResId: Int) {
        val iconMap = mapOf(
            R.drawable.ic_food to binding.iconFood,
            R.drawable.ic_shopping to binding.iconShopping,
            R.drawable.ic_transport to binding.iconTransport,
            R.drawable.ic_entertainment to binding.iconEntertainment,
            R.drawable.ic_health to binding.iconHealth,
            R.drawable.ic_education to binding.iconEducation,
            R.drawable.ic_bills to binding.iconBills,
            R.drawable.ic_other to binding.iconOther
        )

        iconMap.values.forEach { it.setBackgroundResource(R.drawable.bg_icon_unselected) }
        iconMap[iconResId]?.setBackgroundResource(R.drawable.bg_icon_selected)
    }

    private fun getSelectedIconResId(): Int {
        val selectedBg = resources.getDrawable(R.drawable.bg_icon_selected, null).constantState
        return when {
            binding.iconFood.background.constantState == selectedBg -> R.drawable.ic_food
            binding.iconShopping.background.constantState == selectedBg -> R.drawable.ic_shopping
            binding.iconTransport.background.constantState == selectedBg -> R.drawable.ic_transport
            binding.iconEntertainment.background.constantState == selectedBg -> R.drawable.ic_entertainment
            binding.iconHealth.background.constantState == selectedBg -> R.drawable.ic_health
            binding.iconEducation.background.constantState == selectedBg -> R.drawable.ic_education
            binding.iconBills.background.constantState == selectedBg -> R.drawable.ic_bills
            else -> R.drawable.ic_other
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

    companion object {
        private const val ARG_CATEGORY = "category"

        fun newInstance(category: Category?): AddCategoryDialogFragment {
            val fragment = AddCategoryDialogFragment()
            val args = Bundle()
            category?.let { args.putParcelable(ARG_CATEGORY, it) }
            fragment.arguments = args
            return fragment
        }
    }
}
