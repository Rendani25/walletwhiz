package com.walletwiz.ui.profile

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.SeekBar
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import com.walletwiz.databinding.FragmentProfileBinding
import com.walletwiz.ui.auth.LoginActivity
import com.walletwiz.viewmodel.UserViewModel
import java.text.NumberFormat
import java.util.*

class ProfileFragment : Fragment() {

    private var _binding: FragmentProfileBinding? = null
    private val binding get() = _binding!!

    private lateinit var userViewModel: UserViewModel
    private val currencyFormat = NumberFormat.getCurrencyInstance(Locale.getDefault())

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentProfileBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        userViewModel = ViewModelProvider(requireActivity())[UserViewModel::class.java]

        // Observe live user data
        userViewModel.currentUser.observe(viewLifecycleOwner) { user ->
            if (user != null) {
                binding.userNameText.text = user.fullName
                binding.userEmailText.text = user.email

                binding.minBudgetSeekBar.progress = user.minBudgetGoal.toInt()
                binding.maxBudgetSeekBar.progress = user.maxBudgetGoal.toInt()

                updateMinBudgetText(user.minBudgetGoal.toInt())
                updateMaxBudgetText(user.maxBudgetGoal.toInt())
            }
        }

        // Min budget SeekBar
        binding.minBudgetSeekBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                updateMinBudgetText(progress)
                if (progress > binding.maxBudgetSeekBar.progress) {
                    binding.maxBudgetSeekBar.progress = progress
                    updateMaxBudgetText(progress)
                }
            }

            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })

        // Max budget SeekBar
        binding.maxBudgetSeekBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                updateMaxBudgetText(progress)
                if (progress < binding.minBudgetSeekBar.progress) {
                    binding.minBudgetSeekBar.progress = progress
                    updateMinBudgetText(progress)
                }
            }

            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })

        // Save budget goals button
        binding.saveBudgetButton.setOnClickListener {
            val minBudget = binding.minBudgetSeekBar.progress.toDouble()
            val maxBudget = binding.maxBudgetSeekBar.progress.toDouble()
            userViewModel.updateBudgetGoals(minBudget, maxBudget)
            Toast.makeText(requireContext(), "Budget goals updated", Toast.LENGTH_SHORT).show()
        }

        // Logout
        binding.logoutButton.setOnClickListener {
            userViewModel.logout()
            startActivity(Intent(requireContext(), LoginActivity::class.java))
            requireActivity().finish()
        }
    }

    private fun updateMinBudgetText(value: Int) {
        binding.minBudgetText.text = "Minimum Monthly Goal: ${currencyFormat.format(value)}"
    }

    private fun updateMaxBudgetText(value: Int) {
        binding.maxBudgetText.text = "Maximum Monthly Goal: ${currencyFormat.format(value)}"
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
