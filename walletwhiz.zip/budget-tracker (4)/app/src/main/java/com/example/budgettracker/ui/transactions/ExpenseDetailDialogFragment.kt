package com.example.budgettracker.ui.transactions

import android.net.Uri
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.DialogFragment
import androidx.lifecycle.ViewModelProvider
import com.walletwiz.R
import com.walletwiz.databinding.DialogExpenseDetailBinding
import com.example.budgettracker.viewmodel.CategoryViewModel
import com.example.budgettracker.viewmodel.ExpenseViewModel
import java.text.SimpleDateFormat
import java.util.*

class ExpenseDetailDialogFragment : DialogFragment() {
    private var _binding: DialogExpenseDetailBinding? = null
    private val binding get() = _binding!!

    private lateinit var expenseViewModel: ExpenseViewModel
    private lateinit var categoryViewModel: CategoryViewModel
    
    private val dateFormat = SimpleDateFormat("MMM dd, yyyy", Locale.getDefault())
    private val timeFormat = SimpleDateFormat("HH:mm", Locale.getDefault())

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = DialogExpenseDetailBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        expenseViewModel = ViewModelProvider(requireActivity())[ExpenseViewModel::class.java]
        categoryViewModel = ViewModelProvider(requireActivity())[CategoryViewModel::class.java]

        val expenseId = arguments?.getLong(ARG_EXPENSE_ID) ?: return

        expenseViewModel.getExpenseById(expenseId).observe(viewLifecycleOwner) { expense ->
            if (expense != null) {
                // Set expense details
                binding.expenseTitle.text = expense.description
                
                val amountText = if (expense.isIncome) "+$${String.format("%.2f", expense.amount)}" 
                                else "-$${String.format("%.2f", expense.amount)}"
                binding.expenseAmount.text = amountText
                
                // Set amount text color
                val colorResId = if (expense.isIncome) R.color.income_green else R.color.expense_red
                binding.expenseAmount.setTextColor(
                    requireContext().getColor(colorResId)
                )
                
                // Format date and time
                val date = Date(expense.date)
                binding.expenseDate.text = dateFormat.format(date)
                
                val startTime = Date(expense.startTime)
                val endTime = Date(expense.endTime)
                binding.expenseTime.text = "${timeFormat.format(startTime)} - ${timeFormat.format(endTime)}"
                
                // Load category
                categoryViewModel.getCategoryById(expense.categoryId).observe(viewLifecycleOwner) { category ->
                    if (category != null) {
                        binding.categoryIcon.setImageResource(category.iconResId)
                        binding.categoryName.text = category.name
                    }
                }
                
                // Handle photo
                if (expense.photoUri.isNotEmpty()) {
                    try {
                        binding.photoContainer.visibility = View.VISIBLE
                        binding.expensePhoto.setImageURI(Uri.parse(expense.photoUri))
                    } catch (e: Exception) {
                        binding.photoContainer.visibility = View.GONE
                    }
                } else {
                    binding.photoContainer.visibility = View.GONE
                }
            }
        }

        // Close button
        binding.closeButton.setOnClickListener {
            dismiss()
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

    companion object {
        private const val ARG_EXPENSE_ID = "expense_id"

        fun newInstance(expenseId: Long): ExpenseDetailDialogFragment {
            val fragment = ExpenseDetailDialogFragment()
            val args = Bundle()
            args.putLong(ARG_EXPENSE_ID, expenseId)
            fragment.arguments = args
            return fragment
        }
    }
}
