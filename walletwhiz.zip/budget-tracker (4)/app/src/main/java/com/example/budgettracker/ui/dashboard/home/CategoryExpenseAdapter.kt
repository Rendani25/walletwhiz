package com.example.budgettracker.ui.dashboard.home

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.walletwiz.databinding.ItemCategoryExpenseBinding
import com.example.budgettracker.model.Category

data class CategoryExpenseItem(val category: Category, val amount: Double)

class CategoryExpenseAdapter(private val items: List<CategoryExpenseItem>) : 
    RecyclerView.Adapter<CategoryExpenseAdapter.ViewHolder>() {

    class ViewHolder(val binding: ItemCategoryExpenseBinding) : RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding = ItemCategoryExpenseBinding.inflate(
            LayoutInflater.from(parent.context),
            parent,
            false
        )
        return ViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val item = items[position]
        
        holder.binding.categoryIcon.setImageResource(item.category.iconResId)
        holder.binding.categoryName.text = item.category.name
        holder.binding.categoryAmount.text = "-$${String.format("%.2f", item.amount)}"
    }

    override fun getItemCount() = items.size
}
