package com.walletwiz.ui.categories

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import com.example.budgettracker.ui.categories.AddCategoryDialogFragment
import com.example.budgettracker.ui.categories.CategoryAdapter
import com.walletwiz.databinding.FragmentCategoriesBinding
import com.example.budgettracker.viewmodel.CategoryViewModel

class CategoriesFragment : Fragment() {
    private var _binding: FragmentCategoriesBinding? = null
    private val binding get() = _binding!!

    private lateinit var categoryViewModel: CategoryViewModel
    private lateinit var adapter: CategoryAdapter

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentCategoriesBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        categoryViewModel = ViewModelProvider(requireActivity())[CategoryViewModel::class.java]
        
        // Setup RecyclerView
        adapter = CategoryAdapter(
            onEditClick = { category ->
                AddCategoryDialogFragment.newInstance(category).show(
                    childFragmentManager,
                    "EditCategoryDialog"
                )
            },
            onDeleteClick = { category ->
                categoryViewModel.deleteCategory(category)
            }
        )
        binding.categoriesRecyclerView.adapter = adapter

        // Observe categories
        categoryViewModel.getAllCategories().observe(viewLifecycleOwner) { categories ->
            adapter.submitList(categories)
            binding.emptyView.visibility = if (categories.isEmpty()) View.VISIBLE else View.GONE
        }

        // Add category button
        binding.fabAddCategory.setOnClickListener {
            AddCategoryDialogFragment.newInstance(null).show(
                childFragmentManager,
                "AddCategoryDialog"
            )
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
