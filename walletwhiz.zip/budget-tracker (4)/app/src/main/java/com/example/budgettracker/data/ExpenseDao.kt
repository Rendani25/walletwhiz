package com.example.budgettracker.data

import androidx.lifecycle.LiveData
import androidx.room.*
import com.example.budgettracker.model.Expense

@Dao
interface ExpenseDao {
    @Insert
    suspend fun insert(expense: Expense): Long

    @Update
    suspend fun update(expense: Expense)

    @Delete
    suspend fun delete(expense: Expense)

    @Query("SELECT * FROM expenses ORDER BY date DESC")
    fun getAllExpenses(): LiveData<List<Expense>>

    @Query("SELECT * FROM expenses WHERE id = :expenseId LIMIT 1")
    fun getExpenseById(expenseId: Long): LiveData<Expense>

    @Query("SELECT * FROM expenses WHERE date BETWEEN :startDate AND :endDate ORDER BY date DESC")
    fun getExpensesByDateRange(startDate: Long, endDate: Long): LiveData<List<Expense>>

    @Query("SELECT * FROM expenses WHERE strftime('%m', date / 1000, 'unixepoch') = :month AND strftime('%Y', date / 1000, 'unixepoch') = :year ORDER BY date DESC")
    fun getMonthlyExpenses(month: Int, year: String): LiveData<List<Expense>>

    @Query("SELECT SUM(amount) FROM expenses WHERE categoryId = :categoryId AND date BETWEEN :startDate AND :endDate AND isIncome = 0")
    fun getTotalExpenseByCategory(categoryId: Long, startDate: Long, endDate: Long): LiveData<Double?>
}
