package com.walletwiz.ui.transactions

import android.app.DatePickerDialog
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import com.example.budgettracker.ui.transactions.ExpenseDetailDialogFragment
import com.example.budgettracker.ui.transactions.TransactionAdapter
import com.example.budgettracker.ui.transactions.TransactionItem
import com.walletwiz.databinding.FragmentTransactionsBinding
import com.example.budgettracker.viewmodel.CategoryViewModel
import com.example.budgettracker.viewmodel.ExpenseViewModel
import java.text.SimpleDateFormat
import java.util.*

class TransactionsFragment : Fragment() {
    private var _binding: FragmentTransactionsBinding? = null
    private val binding get() = _binding!!

    private lateinit var expenseViewModel: ExpenseViewModel
    private lateinit var categoryViewModel: CategoryViewModel
    private lateinit var adapter: TransactionAdapter

    private val dateFormat = SimpleDateFormat("MMM dd, yyyy", Locale.getDefault())
    private var startDate: Calendar = Calendar.getInstance().apply {
        set(Calendar.DAY_OF_MONTH, 1) // First day of current month
    }
    private var endDate: Calendar = Calendar.getInstance() // Current date

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentTransactionsBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        expenseViewModel = ViewModelProvider(requireActivity())[ExpenseViewModel::class.java]
        categoryViewModel = ViewModelProvider(requireActivity())[CategoryViewModel::class.java]

        // Setup date range
        updateDateRangeText()
        
        binding.startDateButton.setOnClickListener {
            showDatePicker(true)
        }
        
        binding.endDateButton.setOnClickListener {
            showDatePicker(false)
        }

        // Setup RecyclerView
        adapter = TransactionAdapter(
            onItemClick = { expense ->
                // Show expense details
                ExpenseDetailDialogFragment.newInstance(expense.id).show(
                    childFragmentManager,
                    "ExpenseDetailDialog"
                )
            }
        )
        binding.transactionsRecyclerView.adapter = adapter

        // Load transactions for the selected date range
        loadTransactions()
    }

    private fun updateDateRangeText() {
        binding.startDateText.text = dateFormat.format(startDate.time)
        binding.endDateText.text = dateFormat.format(endDate.time)
    }

    private fun showDatePicker(isStartDate: Boolean) {
        val calendar = if (isStartDate) startDate else endDate
        
        DatePickerDialog(
            requireContext(),
            { _, year, month, dayOfMonth ->
                if (isStartDate) {
                    startDate.set(year, month, dayOfMonth)
                    // Ensure start date is not after end date
                    if (startDate.after(endDate)) {
                        startDate = endDate.clone() as Calendar
                    }
                } else {
                    endDate.set(year, month, dayOfMonth)
                    // Ensure end date is not before start date
                    if (endDate.before(startDate)) {
                        endDate = startDate.clone() as Calendar
                    }
                }
                
                updateDateRangeText()
                loadTransactions()
            },
            calendar.get(Calendar.YEAR),
            calendar.get(Calendar.MONTH),
            calendar.get(Calendar.DAY_OF_MONTH)
        ).show()
    }

    private fun loadTransactions() {
        // Set start time to beginning of day
        val start = startDate.clone() as Calendar
        start.set(Calendar.HOUR_OF_DAY, 0)
        start.set(Calendar.MINUTE, 0)
        start.set(Calendar.SECOND, 0)
        
        // Set end time to end of day
        val end = endDate.clone() as Calendar
        end.set(Calendar.HOUR_OF_DAY, 23)
        end.set(Calendar.MINUTE, 59)
        end.set(Calendar.SECOND, 59)
        
        expenseViewModel.getExpensesByDateRange(start.timeInMillis, end.timeInMillis)
            .observe(viewLifecycleOwner) { expenses ->
                categoryViewModel.getAllCategories().observe(viewLifecycleOwner) { categories ->
                    val categoryMap = categories.associateBy { it.id }
                    
                    val transactionItems = expenses.map { expense ->
                        val category = categoryMap[expense.categoryId]
                        TransactionItem(expense, category)
                    }
                    
                    adapter.submitList(transactionItems)
                    binding.emptyView.visibility = if (expenses.isEmpty()) View.VISIBLE else View.GONE
                }
            }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
