package com.example.budgettracker.ui.transactions

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.walletwiz.R
import com.walletwiz.databinding.ItemTransactionBinding
import com.example.budgettracker.model.Category
import com.example.budgettracker.model.Expense
import java.text.SimpleDateFormat
import java.util.*

data class TransactionItem(val expense: Expense, val category: Category?)

class TransactionAdapter(
    private val onItemClick: (Expense) -> Unit
) : ListAdapter<TransactionItem, TransactionAdapter.ViewHolder>(TransactionDiffCallback()) {

    class ViewHolder(val binding: ItemTransactionBinding) : RecyclerView.ViewHolder(binding.root)

    private val dateFormat = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault())

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding = ItemTransactionBinding.inflate(
            LayoutInflater.from(parent.context),
            parent,
            false
        )
        return ViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val item = getItem(position)
        val expense = item.expense
        val category = item.category
        
        // Format date
        val date = Date(expense.date)
        holder.binding.transactionDate.text = dateFormat.format(date)
        
        // Set category info
        if (category != null) {
            holder.binding.categoryIcon.setImageResource(category.iconResId)
            holder.binding.categoryName.text = category.name
        } else {
            holder.binding.categoryIcon.setImageResource(R.drawable.ic_other)
            holder.binding.categoryName.text = "Unknown Category"
        }
        
        // Set amount
        val amountText = if (expense.isIncome) "+$${String.format("%.2f", expense.amount)}" 
                         else "-$${String.format("%.2f", expense.amount)}"
        holder.binding.transactionAmount.text = amountText
        
        // Set amount text color
        val colorResId = if (expense.isIncome) R.color.income_green else R.color.expense_red
        holder.binding.transactionAmount.setTextColor(
            holder.itemView.context.getColor(colorResId)
        )
        
        // Set photo indicator
        holder.binding.photoIndicator.visibility = 
            if (expense.photoUri.isNotEmpty()) ViewGroup.VISIBLE else ViewGroup.GONE
        
        // Set click listener
        holder.itemView.setOnClickListener {
            onItemClick(expense)
        }
    }

    class TransactionDiffCallback : DiffUtil.ItemCallback<TransactionItem>() {
        override fun areItemsTheSame(oldItem: TransactionItem, newItem: TransactionItem): Boolean {
            return oldItem.expense.id == newItem.expense.id
        }

        override fun areContentsTheSame(oldItem: TransactionItem, newItem: TransactionItem): Boolean {
            return oldItem == newItem
        }
    }
}
