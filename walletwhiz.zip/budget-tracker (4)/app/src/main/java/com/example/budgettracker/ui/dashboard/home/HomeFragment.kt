package com.walletwiz.ui.dashboard.home

import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import com.walletwiz.databinding.FragmentHomeBinding
import com.example.budgettracker.model.Category
import com.example.budgettracker.ui.dashboard.home.CategoryExpenseAdapter
import com.example.budgettracker.ui.dashboard.home.CategoryExpenseItem
import com.example.budgettracker.viewmodel.CategoryViewModel
import com.example.budgettracker.viewmodel.ExpenseViewModel
import com.example.budgettracker.viewmodel.UserViewModel
import com.github.mikephil.charting.data.PieData
import com.github.mikephil.charting.data.PieDataSet
import com.github.mikephil.charting.data.PieEntry
import com.github.mikephil.charting.utils.ColorTemplate
import java.util.*

class HomeFragment : Fragment() {
    private var _binding: FragmentHomeBinding? = null
    private val binding get() = _binding!!

    private lateinit var userViewModel: UserViewModel
    private lateinit var expenseViewModel: ExpenseViewModel
    private lateinit var categoryViewModel: CategoryViewModel

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentHomeBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        userViewModel = ViewModelProvider(requireActivity())[UserViewModel::class.java]
        expenseViewModel = ViewModelProvider(requireActivity())[ExpenseViewModel::class.java]
        categoryViewModel = ViewModelProvider(requireActivity())[CategoryViewModel::class.java]

        // Set welcome message
        userViewModel.getCurrentUser().observe(viewLifecycleOwner) { user ->
            binding.welcomeText.text = if (user != null && user.fullName.isNotEmpty()) {
                "Welcome\n${user.fullName} 👋"
            } else {
                "Welcome\nUser 👋"
            }
        }

        // Load pie chart and category expense list
        loadExpenseData()
        setupCategoryExpenseList()
    }

    private fun loadExpenseData() {
        val calendar = Calendar.getInstance()
        val currentMonth = calendar.get(Calendar.MONTH)
        val currentYear = calendar.get(Calendar.YEAR)

        expenseViewModel.getMonthlyExpenses(currentMonth, currentYear)
            .observe(viewLifecycleOwner) { expenses ->
                val onlyExpenses = expenses.filter { !it.isIncome }

                if (onlyExpenses.isEmpty()) {
                    Log.d("HomeFragment", "No expenses (excluding income) for the current month.")
                    binding.expensesChart.clear()
                    binding.expensesChart.invalidate()
                    return@observe
                }

                categoryViewModel.getAllCategories()
                    .observe(viewLifecycleOwner) { categories ->
                        if (categories.isNullOrEmpty()) {
                            Log.d("HomeFragment", "No categories found.")
                            return@observe
                        }

                        val categoryMap = categories.associateBy { it.id }
                        val categoryExpenses = onlyExpenses.groupBy { it.categoryId }

                        val entries = categoryExpenses.mapNotNull { (categoryId, expenseList) ->
                            val total = expenseList.sumOf { it.amount.toDouble() }
                            val categoryName = categoryMap[categoryId]?.name
                            if (categoryName != null) {
                                Log.d("HomeFragment", "Category: $categoryName, Total: $total")
                                PieEntry(total.toFloat(), categoryName)
                            } else {
                                Log.w("HomeFragment", "Category ID $categoryId not found in category list")
                                null
                            }
                        }

                        if (entries.isEmpty()) {
                            binding.expensesChart.clear()
                            binding.expensesChart.invalidate()
                            return@observe
                        }

                        val dataSet = PieDataSet(entries, "Expenses by Category").apply {
                            colors = ColorTemplate.MATERIAL_COLORS.toList()
                            valueTextSize = 14f
                        }

                        binding.expensesChart.apply {
                            data = PieData(dataSet)
                            description.isEnabled = false
                            legend.isEnabled = true
                            setUsePercentValues(true)
                            setEntryLabelColor(android.graphics.Color.BLACK)
                            invalidate()
                        }
                    }
            }
    }

    private fun setupCategoryExpenseList() {
        val calendar = Calendar.getInstance()
        val currentMonth = calendar.get(Calendar.MONTH)
        val currentYear = calendar.get(Calendar.YEAR)

        expenseViewModel.getMonthlyExpenses(currentMonth, currentYear)
            .observe(viewLifecycleOwner) { expenses ->
                val onlyExpenses = expenses.filter { !it.isIncome }

                if (onlyExpenses.isNotEmpty()) {
                    Log.d("HomeFragment", "Filtered expenses: ${onlyExpenses.size}")

                    val categoryExpenses = onlyExpenses.groupBy { it.categoryId }

                    categoryViewModel.getAllCategories().observe(viewLifecycleOwner) { categories ->
                        Log.d("HomeFragment", "Categories loaded: ${categories.size}")
                        val categoryMap = categories.associateBy { it.id }

                        val categoryExpenseItems = categoryExpenses.map { (categoryId, expenseList) ->
                            val total = expenseList.sumOf { it.amount.toDouble() }
                            val category = categoryMap[categoryId] ?: Category(0, "Unknown", "", 0)
                            CategoryExpenseItem(category, total)
                        }

                        val adapter = CategoryExpenseAdapter(categoryExpenseItems)
                        binding.categoryExpensesList.adapter = adapter
                    }
                } else {
                    Log.d("HomeFragment", "No expenses found for category list.")
                }
            }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
