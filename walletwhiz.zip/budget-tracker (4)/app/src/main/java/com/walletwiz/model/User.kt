package com.walletwiz.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "users")
data class User(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val fullName: String,
    val email: String,
    val password: String,
    val minBudgetGoal: Double = 500.0,
    val maxBudgetGoal: Double = 2000.0
)
