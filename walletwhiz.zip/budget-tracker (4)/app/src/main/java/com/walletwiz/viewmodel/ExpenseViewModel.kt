package com.walletwiz.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.viewModelScope
import com.walletwiz.data.AppDatabase
import com.walletwiz.data.ExpenseDao
import com.walletwiz.model.Expense
import kotlinx.coroutines.launch

class ExpenseViewModel(application: Application) : AndroidViewModel(application) {
    private val expenseDao: ExpenseDao

    init {
        val database = AppDatabase.getDatabase(application)
        expenseDao = database.expenseDao()
    }

    fun getAllExpenses(): LiveData<List<Expense>> {
        return expenseDao.getAllExpenses()
    }

    fun getExpenseById(expenseId: Long): LiveData<Expense> {
        return expenseDao.getExpenseById(expenseId)
    }

    fun getExpensesByDateRange(startDate: Long, endDate: Long): LiveData<List<Expense>> {
        return expenseDao.getExpensesByDateRange(startDate, endDate)
    }

    fun getMonthlyExpenses(month: Int, year: Int): LiveData<List<Expense>> {
        return expenseDao.getMonthlyExpenses(month + 1, year.toString())
    }

    fun getTotalExpenseByCategory(categoryId: Long, startDate: Long, endDate: Long): LiveData<Double?> {
        return expenseDao.getTotalExpenseByCategory(categoryId, startDate, endDate)
    }

    fun insertExpense(expense: Expense) {
        viewModelScope.launch {
            expenseDao.insert(expense)
        }
    }

    fun updateExpense(expense: Expense) {
        viewModelScope.launch {
            expenseDao.update(expense)
        }
    }

    fun deleteExpense(expense: Expense) {
        viewModelScope.launch {
            expenseDao.delete(expense)
        }
    }
}
