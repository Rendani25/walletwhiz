package com.walletwiz.ui.dashboard

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import com.walletwiz.R
import com.walletwiz.databinding.ActivityDashboardBinding
import com.walletwiz.ui.categories.CategoriesFragment
import com.walletwiz.ui.dashboard.home.HomeFragment
import com.walletwiz.ui.profile.ProfileFragment
import com.walletwiz.ui.transactions.AddTransactionActivity
import com.walletwiz.ui.transactions.TransactionsFragment
import com.walletwiz.viewmodel.UserViewModel

class DashboardActivitys : AppCompatActivity() {
    private lateinit var binding: ActivityDashboardBinding
    private lateinit var userViewModel: UserViewModel

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDashboardBinding.inflate(layoutInflater)
        setContentView(binding.root)

        userViewModel = ViewModelProvider(this).get(UserViewModel::class.java)

        // Set default fragment
        if (savedInstanceState == null) {
            loadFragment(HomeFragment())
        }

        // Setup bottom navigation
        binding.bottomNavigation.setOnItemSelectedListener { item ->
            when (item.itemId) {
                R.id.nav_home -> loadFragment(HomeFragment())
                R.id.nav_categories -> loadFragment(CategoriesFragment())
                R.id.nav_transactions -> loadFragment(TransactionsFragment())
                R.id.nav_profile -> loadFragment(ProfileFragment())
            }
            true
        }

        binding.fabAddTransaction.setOnClickListener {
            startActivity(Intent(this, AddTransactionActivity::class.java))
        }
    }

    private fun loadFragment(fragment: Fragment) {
        supportFragmentManager.beginTransaction()
            .replace(R.id.fragmentContainer, fragment)
            .commit()
    }
}
