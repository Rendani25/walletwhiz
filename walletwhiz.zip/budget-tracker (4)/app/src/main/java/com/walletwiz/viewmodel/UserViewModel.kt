package com.walletwiz.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.switchMap
import androidx.lifecycle.viewModelScope
import com.walletwiz.data.AppDatabase
import com.walletwiz.data.UserDao
import com.walletwiz.model.User
import kotlinx.coroutines.launch

class UserViewModel(application: Application) : AndroidViewModel(application) {
    private var userDao: UserDao  = AppDatabase.getDatabase(application).userDao()
    private val currentUserId = MutableLiveData<Long>()

    // LiveData for the current user
    val currentUser: LiveData<User> = currentUserId.switchMap { userId ->
        userDao.getUserById(userId)
    }


    init {
        val database = AppDatabase.getDatabase(application)
        userDao = database.userDao()

        // Check SharedPreferences on init
        val sharedPrefs = application.getSharedPreferences("budget_tracker_prefs", Application.MODE_PRIVATE)
        val userId = sharedPrefs.getLong("current_user_id", -1L)
        if (userId != -1L) {
            currentUserId.value = userId
        }
    }

    fun register(fullName: String, email: String, password: String): LiveData<Boolean> {
        val result = MutableLiveData<Boolean>()

        viewModelScope.launch {
            try {
                val user = User(fullName = fullName, email = email, password = password)
                val userId = userDao.insert(user)
                if (userId > 0) {
                    saveUserToPrefs(userId)
                    currentUserId.postValue(userId)
                    result.postValue(true)
                } else {
                    result.postValue(false)
                }
            } catch (e: Exception) {
                result.postValue(false)
            }
        }

        return result
    }

    // Updated login method using suspend function
    fun login(email: String, password: String): LiveData<Boolean> {
        val result = MutableLiveData<Boolean>()

        viewModelScope.launch {
            try {
                val user = userDao.login(email, password)
                if (user != null) {
                    saveUserToPrefs(user.id)
                    currentUserId.postValue(user.id)
                    result.postValue(true)
                } else {
                    result.postValue(false)
                }
            } catch (e: Exception) {
                result.postValue(false)
            }
        }

        return result
    }

    fun logout() {
        val sharedPrefs = getApplication<Application>().getSharedPreferences("budget_tracker_prefs", Application.MODE_PRIVATE)
        sharedPrefs.edit().remove("current_user_id").apply()
        currentUserId.value = -1L
    }

    fun isUserLoggedIn(): Boolean {
        return currentUserId.value != null && currentUserId.value!! > 0
    }

    fun updateBudgetGoals(minBudget: Double, maxBudget: Double) {
        viewModelScope.launch {
            val userId = currentUserId.value ?: return@launch
            val user = userDao.getUserByIdNow(userId) ?: return@launch
            val updatedUser = user.copy(minBudgetGoal = minBudget, maxBudgetGoal = maxBudget)
            userDao.update(updatedUser)
        }
    }

    private fun saveUserToPrefs(userId: Long) {
        val sharedPrefs = getApplication<Application>().getSharedPreferences("budget_tracker_prefs", Application.MODE_PRIVATE)
        sharedPrefs.edit().putLong("current_user_id", userId).apply()
    }
}
