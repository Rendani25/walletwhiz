package com.walletwiz

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.ViewModelProvider
import com.walletwiz.databinding.ActivityMainBinding
import com.walletwiz.ui.auth.LoginActivity
import com.walletwiz.ui.auth.GetStartedActivity
import com.walletwiz.viewmodel.UserViewModel

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding
    private lateinit var userViewModel: UserViewModel

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        userViewModel = ViewModelProvider(this)[UserViewModel::class.java]

        // Check if user is logged in
        if (!userViewModel.isUserLoggedIn()) {
            // Redirect to login screen
            startActivity(Intent(this, LoginActivity::class.java))
            finish()
        } else {
            // Redirect to GetStarted screen instead of showing a button
            startActivity(Intent(this, GetStartedActivity::class.java))
            finish()
        }
    }
}
