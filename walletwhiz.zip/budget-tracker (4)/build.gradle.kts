plugins {
    kotlin("android") version "1.9.23" // use this version or another recent 1.9.x version
    kotlin("kapt") version "1.9.23"
}